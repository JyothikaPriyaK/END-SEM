package com.klef.jfsd.exam.service;

import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class ProductService {

    public Object[] getAllProducts() {
        String url = "https://fakestoreapi.com/products";
        RestTemplate restTemplate = new RestTemplate();
        return restTemplate.getForObject(url, Object[].class); // Map to Object[] or Product[] if using model class
    }
}
